//
//  PocketKit.h
//  PocketKit
//
//  Created by Jay Patel on 13/08/21.
//

#import <Foundation/Foundation.h>

//! Project version number for PocketKit.
FOUNDATION_EXPORT double PocketKitVersionNumber;

//! Project version string for PocketKit.
FOUNDATION_EXPORT const unsigned char PocketKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PocketKit/PublicHeader.h>


